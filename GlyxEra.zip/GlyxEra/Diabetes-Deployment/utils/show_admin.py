"""
Show Current Admin - GlyxEra Project
Displays the current admin user of the application
"""

import sys
import os

# Add parent directory to path to import modules
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
sys.path.insert(0, parent_dir)

# Check for database file
db_path = os.path.join(parent_dir, 'glyxera.db')
if not os.path.exists(db_path):
    db_path = os.path.join(current_dir, 'glyxera.db')
    if not os.path.exists(db_path):
        print("[ERROR] Database file 'glyxera.db' not found!")
        sys.exit(1)

try:
    from application import app
    from database import db, User
    
    with app.app_context():
        admin = User.query.filter_by(is_admin=True).first()
        
        print("\n" + "="*50)
        print("         GLYXERA - CURRENT ADMIN")
        print("="*50)
        
        if admin:
            print(f"\nAdmin Email    : {admin.email}")
            print(f"Admin Name     : {admin.name}")
            print(f"Registered On  : {admin.created_at.strftime('%Y-%m-%d %H:%M:%S')}")
            print(f"User ID        : {admin.id}")
        else:
            print("\n[INFO] No admin found in the system.")
        
        print("\n" + "="*50 + "\n")

except Exception as e:
    print(f"[ERROR] Failed to retrieve admin information: {str(e)}")
    sys.exit(1)
