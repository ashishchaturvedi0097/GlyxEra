"""
GlyxEra Health Assessment System - Setup Script
Run this script to set up the project automatically
Usage: python setup.py
"""

import os
import sys
import subprocess

def print_header():
    print("\n" + "="*70)
    print("           GLYXERA HEALTH ASSESSMENT SYSTEM - SETUP")
    print("="*70 + "\n")

def check_python_version():
    print("[1/6] Checking Python version...")
    version = sys.version_info
    if version.major < 3 or (version.major == 3 and version.minor < 8):
        print("    [ERROR] Python 3.8+ required. Current:", f"{version.major}.{version.minor}")
        return False
    print(f"    [OK] Python {version.major}.{version.minor}.{version.micro}")
    return True

def install_dependencies():
    print("\n[2/6] Installing dependencies...")
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "install", "-r", "requirements.txt"])
        print("    [OK] All dependencies installed")
        return True
    except subprocess.CalledProcessError:
        print("    [ERROR] Failed to install dependencies")
        return False

def verify_files():
    print("\n[3/6] Verifying project files...")
    required_files = [
        "application.py",
        "database.py",
        "Model/standardScalar.pkl",
        "Model/modelForPrediction.pkl",
        "Model/mental_health_models.pkl",
        "Dataset/diabetes.csv",
        "Dataset/chatbot_knowledge.json"
    ]
    
    missing = []
    for file in required_files:
        if os.path.exists(file):
            print(f"    [OK] {file}")
        else:
            print(f"    [MISSING] {file}")
            missing.append(file)
    
    if missing:
        print(f"\n    [ERROR] {len(missing)} files missing!")
        return False
    return True

def verify_folders():
    print("\n[4/6] Verifying project structure...")
    required_folders = [
        "Model",
        "Dataset",
        "static",
        "templates",
        "utils"
    ]
    
    for folder in required_folders:
        if os.path.exists(folder):
            print(f"    [OK] {folder}/")
        else:
            print(f"    [MISSING] {folder}/")
            os.makedirs(folder)
            print(f"    [CREATED] {folder}/")
    return True

def initialize_database():
    print("\n[5/6] Initializing database...")
    if os.path.exists("glyxera.db"):
        print("    [INFO] Database already exists")
        return True
    print("    [INFO] Database will be created on first run")
    return True

def print_instructions():
    print("\n[6/6] Setup complete!")
    print("\n" + "="*70)
    print("                    NEXT STEPS")
    print("="*70)
    print("\n1. Start the application:")
    print("   python application.py")
    print("\n2. Browser will open automatically at:")
    print("   http://127.0.0.1:8080")
    print("\n3. Create admin account on first login")
    print("\n4. Explore the features:")
    print("   - Diabetes Risk Assessment")
    print("   - Blood Pressure Check")
    print("   - Mental Health Screening")
    print("   - AI-Powered Chatbot")
    print("\n" + "="*70)
    print("\nUTILITY SCRIPTS:")
    print("  python utils/view_database.py      - View database contents")
    print("  python utils/show_model_accuracy.py - Check AI model accuracy")
    print("  python utils/verify_chatbot.py     - Test chatbot functionality")
    print("  python utils/reset_admin.py        - Reset admin credentials")
    print("  python utils/reset_database.py     - Reset entire database")
    print("\n" + "="*70 + "\n")

def main():
    print_header()
    
    # Run setup steps
    if not check_python_version():
        sys.exit(1)
    
    if not install_dependencies():
        sys.exit(1)
    
    if not verify_files():
        print("\n[ERROR] Setup failed - missing required files")
        sys.exit(1)
    
    verify_folders()
    initialize_database()
    print_instructions()
    
    print("Setup completed successfully! Ready to run.\n")

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\nSetup cancelled by user.")
        sys.exit(1)
    except Exception as e:
        print(f"\n[ERROR] Setup failed: {e}")
        sys.exit(1)
